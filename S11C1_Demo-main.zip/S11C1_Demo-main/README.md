# S11C1_Demo

## Reto por resolver

### A partir del código disponible en este repositorio, implemente herencia de clases en Javascript.

